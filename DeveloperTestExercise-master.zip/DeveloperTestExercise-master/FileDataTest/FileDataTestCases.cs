﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FileDataTest
{
    [TestClass]
    public class FileDataTestCases
    {
        /// <summary>
        /// Check if the argument is passed to the main method
        /// </summary>
        [TestMethod]
        public void ArgumentNullCheck()
        {
            string commandArgument = "";
            string[] arguments = commandArgument.Split(' ');
            FileData.Program.Main(arguments);

            Assert.IsNull(FileData.Program.output);
        }        

        /// <summary>
        /// Check the method returns correct file version for the first scenario
        /// </summary>
        [TestMethod]
        public void SingleHyphenVersionArgumentResultCheck()
        {
            string commandArgument = "-v c:/Test.txt";
            string[] arguments = commandArgument.Split(' ');            
            FileData.Program.Main(arguments);            

            Assert.IsNotNull(FileData.Program.output);
        }

        /// <summary>
        /// Check the method returns correct file version for the second scenario
        /// </summary>
        [TestMethod]
        public void DoubleHyphenVersionArgumentResultCheck()
        {
            string commandArgument = "--v c:/Test.txt";
            string[] arguments = commandArgument.Split(' ');
            FileData.Program.Main(arguments);

            Assert.IsNotNull(FileData.Program.output);
        }

        /// <summary>
        /// Check the method returns correct file version for the third scenario
        /// </summary>
        [TestMethod]
        public void BackSlashVersionArgumentResultCheck()
        {
            string commandArgument = "/v c:/Test.txt";
            string[] arguments = commandArgument.Split(' ');
            FileData.Program.Main(arguments);

            Assert.IsNotNull(FileData.Program.output);
        }

        /// <summary>
        /// Check the method returns correct file size for the first scenario
        /// </summary>
        [TestMethod]
        public void SingleHyphenSizeArgumentResultCheck()
        {
            string commandArgument = "-s c:/Test.txt";
            string[] arguments = commandArgument.Split(' ');
            FileData.Program.Main(arguments);

            Assert.IsNotNull(FileData.Program.output);
        }

        /// <summary>
        /// Check the method returns correct file size for the second scenario
        /// </summary>
        [TestMethod]
        public void DoubleHyphenSizeArgumentResultCheck()
        {
            string commandArgument = "--s c:/Test.txt";
            string[] arguments = commandArgument.Split(' ');
            FileData.Program.Main(arguments);

            Assert.IsNotNull(FileData.Program.output);
        }

        /// <summary>
        /// Check the method returns correct file size for the third scenario
        /// </summary>
        [TestMethod]
        public void BackSlashSizeArgumentResultCheck()
        {
            string commandArgument = "/s c:/Test.txt";
            string[] arguments = commandArgument.Split(' ');
            FileData.Program.Main(arguments);

            Assert.IsNotNull(FileData.Program.output);
        }

    }
}
