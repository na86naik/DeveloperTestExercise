﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static object output = null;

        public static void Main(string[] args)
        {
            // Instantiating the FileDetails class
            FileDetails fileDetails = new FileDetails();

            // Code to check the arguments, call the FileDetails function and return the output.
            if (args.Length > 0)
            {
                // Check the first argument and call the respective method in FileDetails.
                string firstArgument = args[0];
                if (firstArgument.Contains("-") || firstArgument.Contains("--") || firstArgument.Contains("/"))
                {
                    firstArgument = Regex.Replace(firstArgument, @"[^0-9a-zA-Z]+", "");

                    // call the respective methods to return the desired output.
                    switch (firstArgument.ToLower())
                    {
                        case "v":
                            output = fileDetails.Version(args[1]);
                            break;
                        case "s":
                            output = fileDetails.Size(args[1]);
                            break;
                    }
                }
            }

            // Display the output
            Console.WriteLine("{0}", output);
        }
    }
}
